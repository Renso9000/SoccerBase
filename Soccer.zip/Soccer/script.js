function toggleTable() {
    // Get the selected table name from the dropdown
    var selectedTable = document.getElementById("tableSelector").value;

    // Hide all tables
    var tables = document.querySelectorAll('.table-container');
    tables.forEach(function(table) {
        table.style.display = 'none';
    });

    // Show the selected table
    var selectedTableDiv = document.getElementById(selectedTable + "Table");
    var selectedData = document.getElementById(selectedTable + "Data");
    if (selectedTableDiv) {
        selectedTableDiv.style.display = 'table';
    }
    if(selectedData) {
        selectedData.style.display = 'table';
    }
}

// Search function for Teams table
document.getElementById("teamsSearch").addEventListener("input", function () {
    searchTable("teamsData", this.value);
});

// Search function for Players table
document.getElementById("playersSearch").addEventListener("input", function () {
    searchTable("playersData", this.value);
});

// Search function for Matches table
document.getElementById("matchesSearch").addEventListener("input", function () {
    searchTable("matchesData", this.value);
});

// Search function for Goals table
document.getElementById("goalsSearch").addEventListener("input", function () {
    searchTable("goalsData", this.value);
});

// Search function for Assists table
document.getElementById("assistsSearch").addEventListener("input", function () {
    searchTable("assistsData", this.value);
});

// Search function for Accounts table
document.getElementById("accountsSearch").addEventListener("input", function () {
    searchTable("accountsData", this.value);
});

function searchTable(tableId, searchText) {
    var table, rows, cell, i, j;
    table = document.getElementById(tableId);
    rows = table.getElementsByTagName("tr");

    for (i = 1; i < rows.length; i++) {
        var found = false;
        cells = rows[i].getElementsByTagName("td");
        for (j = 0; j < cells.length; j++) {
            cell = cells[j];
            if (cell.innerText.toLowerCase().includes(searchText.toLowerCase())) {
                found = true;
                break;
            }
        }
        rows[i].style.display = found ? "" : "none";
    }
}

