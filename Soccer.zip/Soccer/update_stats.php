<?php
require_once 'dtb.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from the form
    $playerID = $_POST['player_id'];
    $updatedStats = $_POST['updated_stats'];

    // Update the stats in the database using the prepare method from SoccerDatabase
    $updateQuery = "UPDATE player SET Stats = :stats WHERE PlayerID = :playerID";
    $updateStatement = $soccerDB->prepare($updateQuery);
    $updateStatement->bindValue(':stats', $updatedStats);
    $updateStatement->bindValue(':playerID', $playerID);

    try {
        $updateStatement->execute();

        // Fetch the updated stats from the database
        $selectQuery = "SELECT Stats FROM player WHERE PlayerID = :playerID";
        $selectStatement = $soccerDB->prepare($selectQuery);
        $selectStatement->bindValue(':playerID', $playerID);
        $selectStatement->execute();

        // Fetch the updated stats
        $updatedStats = $selectStatement->fetch(PDO::FETCH_ASSOC)['Stats'];

        // Display the updated stats
        echo "Stats updated successfully! Updated Stats: $updatedStats";

        header("Location: admin.php");
    } catch (PDOException $e) {
        echo "Error updating stats: " . $e->getMessage();
    }
}
?>