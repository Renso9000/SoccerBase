<?php
require_once 'dtb.php';

// Create an instance of the SoccerDatabase class
$soccerDB = new SoccerDatabase();

// Fetch all teams
$teams = $soccerDB->getAllTeams();

// Fetch all players
$players = $soccerDB->getAllPlayers();

// Fetch all matches
$matches = $soccerDB->getAllMatches();

// Fetch all goals
$goals = $soccerDB->getAllGoals();

// Fetch all assists
$assists = $soccerDB->getAllAssists();

// Fetch all accounts
$accounts = $soccerDB->getAllAccounts();

// Close the database connection when done
$soccerDB->closeConnection();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soccer Data</title>
    <style>
        table {
            display: none;
            border-collapse: collapse;
            width: 100%;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        .search-input {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

    <label for="tableSelector">Select Table: </label>
    <select id="tableSelector" onchange="toggleTable()">
        <option value="teams">Teams</option>
        <option value="players">Players</option>
        <option value="matches">Matches</option>
        <option value="goals">Goals</option>
        <option value="assists">Assists</option>
        <option value="accounts">Accounts</option>
    </select>

    <div id="teamsTable" class="table-container">
        <h2>Teams</h2>
        <input type="text" class="search-input" id="teamsSearch" placeholder="Search for teams...">
        <?php if (!empty($teams)) : ?>
            <table id="teamsData" class='tabledata'>
                <!-- Table header -->
                <tr>
                    <?php foreach ($teams[0] as $key => $value) : ?>
                        <th><?php echo $key; ?></th>
                    <?php endforeach; ?>
                </tr>
                <!-- Table rows -->
                <?php foreach ($teams as $team) : ?>
                    <tr>
                        <?php foreach ($team as $value) : ?>
                            <td><?php echo $value; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else : ?>
            <p>No teams found.</p>
        <?php endif; ?>
    </div>

    <div id="playersTable" class="table-container">
        <h2>Players</h2>
        <?php if (!empty($players)) : ?>
            <input type="text" class="search-input" id="playersSearch" placeholder="Search for players...">
            <table id="playersData" class='tabledata'>
                <!-- Table header -->
                <tr>
                    <?php foreach ($players[0] as $key => $value) : ?>
                        <th><?php echo $key; ?></th>
                    <?php endforeach; ?>
                </tr>
                <!-- Table rows -->
                <?php foreach ($players as $player) : ?>
                    <tr>
                        <?php foreach ($player as $key => $value) : ?>
                            <?php if ($key !== 'Stats') : ?>
                                <td><?php echo $value; ?></td>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <td>
                            <?php echo $value; ?>
                            <form method="post" action="update_stats.php">
                                <input type="hidden" name="player_id" value="<?php echo $player['PlayerID']; ?>">
                                <input type="text" name="updated_stats" placeholder="Enter updated stats">
                                <button type="submit">Update</button>
                            </form>
                        </td>
                        <td>
                            <form method="post" action="remove_player.php">
                                <input type="hidden" name="player_id" value="<?php echo $player['PlayerID']; ?>">
                                <button type="submit">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else : ?>
            <p>No players found.</p>
        <?php endif; ?>
    </div>

    <div id="matchesTable" class="table-container">
        <h2>Matches</h2>
         <input type="text" class="search-input" id="matchesSearch" placeholder="Search for matches...">
        <?php if (!empty($matches)) : ?>
            <table id="matchesData" class='tabledata'>
                <!-- Table header -->
                <tr>
                    <?php foreach ($matches[0] as $key => $value) : ?>
                        <th><?php echo $key; ?></th>
                    <?php endforeach; ?>
                </tr>
                <!-- Table rows -->
                <?php foreach ($matches as $match) : ?>
                    <tr>
                        <?php foreach ($match as $value) : ?>
                            <td><?php echo $value; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else : ?>
            <p>No matches found.</p>
        <?php endif; ?>
    </div>

    <div id="goalsTable" class="table-container">
        <h2>Goals</h2>
        <input type="text" class="search-input" id="goalsSearch" placeholder="Search for goals...">
        <?php if (!empty($goals)) : ?>
            <table id="goalsData" class='tabledata'>
                <!-- Table header -->
                <tr>
                    <?php foreach ($goals[0] as $key => $value) : ?>
                        <th><?php echo $key; ?></th>
                    <?php endforeach; ?>
                </tr>
                <!-- Table rows -->
                <?php foreach ($goals as $goal) : ?>
                    <tr>
                        <?php foreach ($goal as $value) : ?>
                            <td><?php echo $value; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else : ?>
            <p>No goals found.</p>
        <?php endif; ?>
    </div>

    <div id="assistsTable" class="table-container">
        <h2>Assists</h2>
        <input type="text" class="search-input" id="assistsSearch" placeholder="Search for assists...">
        <?php if (!empty($assists)) : ?>
            <table id="assistsData" class='tabledata'>
                <!-- Table header -->
                <tr>
                    <?php foreach ($assists[0] as $key => $value) : ?>
                        <th><?php echo $key; ?></th>
                    <?php endforeach; ?>
                </tr>
                <!-- Table rows -->
                <?php foreach ($assists as $assist) : ?>
                    <tr>
                        <?php foreach ($assist as $value) : ?>
                            <td><?php echo $value; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else : ?>
            <p>No assists found.</p>
        <?php endif; ?>
    </div>

    <div id="accountsTable" class="table-container">
        <h2>Accounts</h2>
        <input type="text" class="search-input" id="accountsSearch" placeholder="Search for accounts...">
        <?php if (!empty($accounts)) : ?>
            <table id="accountsData" class='tabledata'>
                <!-- Table header -->
                <tr>
                    <?php foreach ($accounts[0] as $key => $value) : ?>
                        <th><?php echo $key; ?></th>
                    <?php endforeach; ?>
                </tr>
                <!-- Table rows -->
                <?php foreach ($accounts as $account) : ?>
                    <tr>
                        <?php foreach ($account as $value) : ?>
                            <td><?php echo $value; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else : ?>
            <p>No accounts found.</p>
        <?php endif; ?>
    </div>

    <script src="script.js"></script>
    <script>
        // Set the default selected table and display it
        document.getElementById("tableSelector").value = "teams";
        toggleTable();
    </script>

</body>
</html>