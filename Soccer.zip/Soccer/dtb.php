<?php
class SoccerDatabase {
    private $pdo;

    // Database credentials
    private $hostname = 'localhost';
    private $database = 'soccer';
    private $username = 'root';
    private $password = '';

    // Constructor to establish the database connection
    public function __construct() {
        $dsn = "mysql:host={$this->hostname};dbname={$this->database}";

        try {
            $this->pdo = new PDO($dsn, $this->username, $this->password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            // echo "Connected to the database successfully!";
        } catch (PDOException $e) {
            // Handle database connection errors
            echo "Connection failed: " . $e->getMessage();
        }
    }

    // New method to prepare a statement
    public function prepare($query) {
        return $this->pdo->prepare($query);
    }

    // Example method to fetch all teams
    public function getAllTeams() {
        $query = "SELECT * FROM team";
        $statement = $this->pdo->query($query);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    // Example method to fetch all players
    public function getAllPlayers() {
        $query = "SELECT * FROM player";
        $statement = $this->pdo->query($query);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    // Example method to fetch all matches
    public function getAllMatches() {
        $query = "SELECT * FROM matches";
        $statement = $this->pdo->query($query);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    // Example method to fetch all goals
    public function getAllGoals() {
        $query = "SELECT * FROM goal";
        $statement = $this->pdo->query($query);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    // Example method to fetch all assists
    public function getAllAssists() {
        $query = "SELECT * FROM assist";
        $statement = $this->pdo->query($query);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    // Example method to fetch all players
    public function getAllAccounts() {
        $query = "SELECT * FROM account";
        $statement = $this->pdo->query($query);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    // Example method to close the database connection
    public function closeConnection() {
        $this->pdo = null;
        // echo "Connection closed.";
    }
    
}

// Create an instance of the SoccerDatabase class
$soccerDB = new SoccerDatabase();