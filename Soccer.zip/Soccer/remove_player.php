<?php
require_once 'dtb.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve player ID from the form
    $playerID = $_POST['player_id'];

    // Delete the player from the database
    $deleteQuery = "DELETE FROM player WHERE PlayerID = :playerID";
    $deleteStatement = $soccerDB->prepare($deleteQuery);
    $deleteStatement->bindValue(':playerID', $playerID);

    try {
        $deleteStatement->execute();
        echo "Player removed successfully!";
        // You can add a link to go back to the admin panel or any other action you desire.
        header("Location: admin.php");
    } catch (PDOException $e) {
        echo "Error removing player: " . $e->getMessage();
    }
}
?>